<?php
/**
 * Created by PhpStorm.
 * User: sardor
 * Date: 10.07.2018
 * Time: 16:27
 */

namespace User\UserBundle\Controller;


use Symfony\Bundle\FrameworkBundle\Controller\Controller;
use User\UserBundle\Entity\User;

class MailController extends  Controller
{
    public function sendMailAction(User $user) {



}

}