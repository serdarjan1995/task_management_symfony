<?php

namespace API\CheckUsernameBundle;

use Symfony\Component\HttpKernel\Bundle\Bundle;

class APICheckUsernameBundle extends Bundle
{
}
