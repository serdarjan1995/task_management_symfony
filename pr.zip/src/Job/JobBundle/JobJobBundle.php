<?php

namespace Job\JobBundle;

use Symfony\Component\HttpKernel\Bundle\Bundle;

class JobJobBundle extends Bundle
{
}
